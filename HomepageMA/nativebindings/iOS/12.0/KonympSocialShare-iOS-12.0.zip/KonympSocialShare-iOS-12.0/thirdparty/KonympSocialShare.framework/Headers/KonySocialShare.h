//
//  KonySocialShare.h
//  KonympSocialShare
//
//  Created by Saikumar Vanaparthi on 06/09/18.
//  Copyright © 2018 Saikumar Vanaparthi. All rights reserved.
//

#import <Foundation/Foundation.h>
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)

@interface KonySocialShare : NSObject

-(instancetype) initWithWindow;
+(void) shareFilepath :(NSArray*)filepaths withTitle:(NSString*)title andOptions:(NSDictionary*)options;

@end
