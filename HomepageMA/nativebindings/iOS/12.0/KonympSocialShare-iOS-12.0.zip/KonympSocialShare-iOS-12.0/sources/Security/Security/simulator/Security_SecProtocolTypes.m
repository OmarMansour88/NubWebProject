#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
}
static void registerCFunctions(JSContext* context)
{
	context[@"sec_identity_create"] = ^sec_identity_t(id arg0) {
		return sec_identity_create(arg0);
	};
	context[@"sec_trust_copy_ref"] = ^id(sec_trust_t arg0) {
		return sec_trust_copy_ref(arg0);
	};
	context[@"sec_identity_create_with_certificates"] = ^sec_identity_t(id arg0, id arg1) {
		return sec_identity_create_with_certificates(arg0, arg1);
	};
	context[@"sec_identity_copy_certificates_ref"] = ^id(sec_identity_t arg0) {
		return sec_identity_copy_certificates_ref(arg0);
	};
	context[@"sec_certificate_copy_ref"] = ^id(sec_certificate_t arg0) {
		return sec_certificate_copy_ref(arg0);
	};
	context[@"sec_trust_create"] = ^sec_trust_t(id arg0) {
		return sec_trust_create(arg0);
	};
	context[@"sec_certificate_create"] = ^sec_certificate_t(id arg0) {
		return sec_certificate_create(arg0);
	};
	context[@"sec_identity_copy_ref"] = ^id(sec_identity_t arg0) {
		return sec_identity_copy_ref(arg0);
	};
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void Security_SecProtocolTypesProtocols()
{
	(void)@protocol(OS_sec_trust);
	(void)@protocol(OS_sec_certificate);
	(void)@protocol(OS_sec_identity);
}
void load_Security_SecProtocolTypes_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
